# Base de Datos - Hai Swimwear

## Instalación

### 1. Requisitos Previos

- **Servidor Web**: Apache o Nginx
- **PHP**: Versión 7.4 o superior
- **MySQL/MariaDB**: Versión 5.7 o superior
- **Extensiones PHP requeridas**:
  - PDO
  - PDO_MySQL
  - mbstring
  - json

### 2. Crear la Base de Datos

```sql
CREATE DATABASE IF NOT EXISTS hai_swimwear CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 3. Importar el Schema

Opción 1: Desde la línea de comandos
```bash
mysql -u root -p hai_swimwear < schema.sql
```

Opción 2: Desde phpMyAdmin
1. Abre phpMyAdmin
2. Selecciona la base de datos `hai_swimwear`
3. Ve a la pestaña "Importar"
4. Selecciona el archivo `schema.sql`
5. Haz clic en "Continuar"

### 4. Configurar la Conexión

Edita el archivo `config.php` y actualiza las siguientes constantes:

```php
define('DB_HOST', 'localhost');      // Host de la base de datos
define('DB_NAME', 'hai_swimwear');   // Nombre de la base de datos
define('DB_USER', 'root');           // Usuario de MySQL
define('DB_PASS', '');               // Contraseña de MySQL
define('APP_URL', 'http://localhost'); // URL de tu aplicación
```

### 5. Crear Usuario de Base de Datos (Recomendado)

Para mayor seguridad, crea un usuario específico para la aplicación:

```sql
CREATE USER 'hai_user'@'localhost' IDENTIFIED BY 'tu_contraseña_segura';
GRANT ALL PRIVILEGES ON hai_swimwear.* TO 'hai_user'@'localhost';
FLUSH PRIVILEGES;
```

Luego actualiza `config.php`:
```php
define('DB_USER', 'hai_user');
define('DB_PASS', 'tu_contraseña_segura');
```

### 6. Permisos de Carpetas

Asegúrate de que la carpeta de uploads tenga permisos de escritura:

```bash
mkdir -p uploads
chmod 755 uploads
```

## Estructura de Tablas

### Tablas Principales

1. **usuarios** - Administradores del sistema
2. **categorias** - Categorías de productos
3. **productos** - Productos del catálogo
4. **producto_imagenes** - Imágenes de productos
5. **producto_atributos** - Atributos (tallas, colores, etc.)
6. **clientes** - Base de datos de clientes
7. **pedidos** - Pedidos realizados
8. **pedido_items** - Items de cada pedido
9. **mensajes** - Mensajes/consultas de clientes
10. **cotizaciones** - Cotizaciones
11. **cotizacion_items** - Items de cotizaciones
12. **imagenes_web** - Imágenes del sitio web
13. **movimientos_inventario** - Historial de movimientos de stock
14. **configuracion** - Configuración del sistema
15. **ventas** - Registro de ventas para reportes

## Credenciales por Defecto

**Usuario Administrador:**
- Email: `admin@haiswimwear.com`
- Contraseña: `admin123`

⚠️ **IMPORTANTE**: Cambia la contraseña del administrador después de la primera instalación.

## Uso de la API PHP

### Ejemplo: Obtener Productos

```php
<?php
require_once 'database/config.php';

// Obtener todos los productos activos
$productos = fetchAll("SELECT * FROM productos WHERE estado = 'activo' ORDER BY fecha_creacion DESC");

foreach ($productos as $producto) {
    echo $producto['nombre'] . " - " . formatCurrency($producto['precio']) . "\n";
}
?>
```

### Ejemplo: Insertar Producto

```php
<?php
require_once 'database/config.php';

$sql = "INSERT INTO productos (nombre, sku, slug, categoria_id, precio, stock, estado) 
        VALUES (?, ?, ?, ?, ?, ?, ?)";

$params = [
    'Bikini Soporte Máximo',
    'HAI-BIK-001',
    'bikini-soporte-maximo',
    1,
    29990,
    15,
    'activo'
];

$id = insertAndGetId($sql, $params);
echo "Producto creado con ID: " . $id;
?>
```

### Ejemplo: Autenticación

```php
<?php
require_once 'database/config.php';

session_start();

if ($_POST['email'] && $_POST['password']) {
    $user = fetchOne("SELECT * FROM usuarios WHERE email = ? AND activo = 1", [$_POST['email']]);
    
    if ($user && password_verify($_POST['password'], $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['rol'];
        $_SESSION['user_name'] = $user['nombre'];
        
        header('Location: index.php');
    } else {
        echo "Credenciales incorrectas";
    }
}
?>
```

## Seguridad

1. **Cambiar contraseñas por defecto**
2. **Usar HTTPS en producción**
3. **Validar todas las entradas del usuario**
4. **Usar consultas preparadas (ya implementado)**
5. **Limitar intentos de login**
6. **Hacer backups regulares de la base de datos**

## Backup

### Crear Backup

```bash
mysqldump -u root -p hai_swimwear > backup_$(date +%Y%m%d).sql
```

### Restaurar Backup

```bash
mysql -u root -p hai_swimwear < backup_20240101.sql
```

## Soporte

Para más información, consulta la documentación de PHP PDO y MySQL.

