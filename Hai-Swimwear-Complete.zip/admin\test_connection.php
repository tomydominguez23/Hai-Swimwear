<?php
/**
 * Script de prueba de conexión a la base de datos
 * Abre este archivo en tu navegador para verificar la conexión
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Prueba de Conexión a Supabase</h1>";
echo "<pre>";

// 1. Verificar que el archivo de configuración existe
echo "1. Verificando archivo de configuración...\n";
if (file_exists('../database/config_supabase.php')) {
    echo "   ✅ Archivo config_supabase.php encontrado\n";
    require_once '../database/config_supabase.php';
} else {
    echo "   ❌ ERROR: No se encuentra config_supabase.php\n";
    echo "   Ruta esperada: " . realpath('../database/') . "/config_supabase.php\n";
    exit;
}

// 2. Verificar constantes
echo "\n2. Verificando constantes de configuración...\n";
$required = ['SUPABASE_HOST', 'SUPABASE_DB', 'SUPABASE_USER', 'SUPABASE_PASS', 'SUPABASE_PORT'];
$allOk = true;
foreach ($required as $const) {
    if (defined($const)) {
        $value = constant($const);
        if ($const === 'SUPABASE_PASS') {
            echo "   ✅ $const: " . (empty($value) ? "❌ VACÍA" : "✅ Configurada (" . strlen($value) . " caracteres)") . "\n";
        } else {
            echo "   ✅ $const: $value\n";
        }
        if (empty($value) && $const !== 'SUPABASE_PASS') {
            $allOk = false;
        }
    } else {
        echo "   ❌ $const: NO DEFINIDA\n";
        $allOk = false;
    }
}

if (!$allOk) {
    echo "\n❌ ERROR: Faltan constantes de configuración\n";
    exit;
}

// 3. Verificar extensión PDO PostgreSQL
echo "\n3. Verificando extensión PDO PostgreSQL...\n";
if (extension_loaded('pdo_pgsql')) {
    echo "   ✅ Extensión pdo_pgsql cargada\n";
} else {
    echo "   ❌ ERROR: Extensión pdo_pgsql NO está cargada\n";
    echo "   Necesitas instalar php-pgsql en tu servidor\n";
    exit;
}

// 4. Intentar conexión
echo "\n4. Intentando conectar a Supabase...\n";
try {
    $dsn = "pgsql:host=" . SUPABASE_HOST . 
           ";port=" . SUPABASE_PORT . 
           ";dbname=" . SUPABASE_DB . 
           ";sslmode=require";
    
    echo "   DSN: pgsql:host=" . SUPABASE_HOST . ";port=" . SUPABASE_PORT . ";dbname=" . SUPABASE_DB . ";sslmode=require\n";
    
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    
    $conn = new PDO($dsn, SUPABASE_USER, SUPABASE_PASS, $options);
    echo "   ✅ Conexión exitosa!\n";
    
    // 5. Verificar versión de PostgreSQL
    echo "\n5. Verificando versión de PostgreSQL...\n";
    $stmt = $conn->query("SELECT version() as version");
    $result = $stmt->fetch();
    echo "   ✅ Versión: " . substr($result['version'], 0, 50) . "...\n";
    
    // 6. Verificar tablas
    echo "\n6. Verificando tablas en la base de datos...\n";
    $stmt = $conn->query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $requiredTables = ['usuarios', 'productos', 'categorias', 'pedidos', 'clientes', 'mensajes', 'cotizaciones', 'imagenes_web', 'configuracion'];
    $foundTables = [];
    
    foreach ($tables as $table) {
        $foundTables[] = $table;
        if (in_array($table, $requiredTables)) {
            echo "   ✅ Tabla '$table' existe\n";
        }
    }
    
    $missingTables = array_diff($requiredTables, $foundTables);
    if (!empty($missingTables)) {
        echo "\n   ⚠️  Tablas faltantes:\n";
        foreach ($missingTables as $table) {
            echo "      - $table\n";
        }
    }
    
    // 7. Verificar usuario admin
    echo "\n7. Verificando usuario administrador...\n";
    try {
        $stmt = $conn->query("SELECT id, nombre, email, rol, activo FROM usuarios WHERE email = 'admin@haiswimwear.com'");
        $admin = $stmt->fetch();
        if ($admin) {
            echo "   ✅ Usuario admin encontrado:\n";
            echo "      - ID: " . $admin['id'] . "\n";
            echo "      - Nombre: " . $admin['nombre'] . "\n";
            echo "      - Email: " . $admin['email'] . "\n";
            echo "      - Rol: " . $admin['rol'] . "\n";
            echo "      - Activo: " . ($admin['activo'] ? 'Sí' : 'No') . "\n";
        } else {
            echo "   ⚠️  Usuario admin NO encontrado\n";
            echo "   Ejecuta: database/crear_usuario_admin.sql en Supabase\n";
        }
    } catch (PDOException $e) {
        echo "   ⚠️  Error al verificar usuario: " . $e->getMessage() . "\n";
    }
    
    // 8. Verificar funciones helper
    echo "\n8. Verificando funciones helper...\n";
    $functions = ['getDB', 'fetchOne', 'fetchAll', 'executeQuery', 'insertAndGetId', 'isAuthenticated', 'jsonResponse'];
    foreach ($functions as $func) {
        if (function_exists($func)) {
            echo "   ✅ Función '$func' disponible\n";
        } else {
            echo "   ❌ Función '$func' NO disponible\n";
        }
    }
    
    // 9. Prueba de consulta simple
    echo "\n9. Prueba de consulta simple...\n";
    try {
        $result = fetchOne("SELECT COUNT(*) as total FROM productos");
        echo "   ✅ Consulta exitosa. Total productos: " . ($result['total'] ?? 0) . "\n";
    } catch (Exception $e) {
        echo "   ❌ Error en consulta: " . $e->getMessage() . "\n";
    }
    
    echo "\n✅ TODAS LAS PRUEBAS COMPLETADAS\n";
    echo "\nSi todas las pruebas pasaron, la conexión está funcionando correctamente.\n";
    
} catch (PDOException $e) {
    echo "   ❌ ERROR de conexión: " . $e->getMessage() . "\n";
    echo "\nPosibles causas:\n";
    echo "1. Credenciales incorrectas (host, usuario, contraseña)\n";
    echo "2. Firewall bloqueando la conexión\n";
    echo "3. SSL requerido pero no disponible\n";
    echo "4. Puerto 5432 bloqueado\n";
    echo "\nVerifica:\n";
    echo "- Que SUPABASE_HOST sea correcto\n";
    echo "- Que SUPABASE_PASS sea la contraseña de la base de datos (NO la API Key)\n";
    echo "- Que tu servidor tenga acceso a internet\n";
}

echo "</pre>";
?>

