# Carpeta de Uploads

Esta carpeta contiene las imágenes subidas desde el panel de administración.

## Permisos

Asegúrate de que esta carpeta tenga permisos de escritura:
- Linux/Mac: `chmod 755 uploads/`
- Windows: Verifica que el servidor web tenga permisos de escritura

## Estructura

Las imágenes se guardan con el formato:
```
{timestamp}_{nombre_original}.{extension}
```

Ejemplo: `65a1b2c3d4e5f_imagen.jpg`

