// API Base URL
const API_BASE = 'api.php';

// Datos en memoria (se cargan desde la API)
let productos = [];
let pedidos = [];
let clientes = [];
let mensajes = [];
let cotizaciones = [];
let imagenes = [];
let categorias = [];

// Initialize
document.addEventListener('DOMContentLoaded', async function() {
    await initializeApp();
});

async function initializeApp() {
    setupNavigation();
    setupModals();
    setupForms();
    await loadDashboard();
    await loadCategorias();
    await loadProductos();
    await loadPedidos();
    await loadMensajes();
    await loadClientes();
    await loadCotizaciones();
    await loadImagenes();
    setupImageUpload();
    setupTabs();
}

// Navigation
function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const pages = document.querySelectorAll('.page');
    const menuToggle = document.getElementById('menuToggle');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');

    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const pageId = this.getAttribute('data-page');
            
            // Update active nav item
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
            
            // Show corresponding page
            pages.forEach(page => page.classList.remove('active'));
            const targetPage = document.getElementById(pageId);
            if (targetPage) {
                targetPage.classList.add('active');
                updatePageTitle(pageId);
            }
            
            // Close sidebar on mobile
            if (window.innerWidth <= 1024) {
                sidebar.classList.remove('active');
            }
        });
    });

    // Menu toggle
    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });
    }

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });
    }

    // Quick actions
    document.querySelectorAll('.action-card').forEach(card => {
        card.addEventListener('click', function() {
            const action = this.getAttribute('data-action');
            handleQuickAction(action);
        });
    });
}

function updatePageTitle(pageId) {
    const titles = {
        'dashboard': 'Panel de Administración',
        'productos': 'Gestión de Productos',
        'categorias': 'Gestión de Categorías',
        'inventario': 'Control de Inventario',
        'pedidos': 'Gestión de Pedidos',
        'clientes': 'Gestión de Clientes',
        'mensajes': 'Centro de Mensajes',
        'cotizaciones': 'Gestión de Cotizaciones',
        'imagenes': 'Gestión de Imágenes Web',
        'ventas': 'Ventas',
        'reportes': 'Análisis y Reportes',
        'configuracion': 'Configuración del Sistema'
    };
    
    const pageTitle = document.getElementById('pageTitle');
    if (pageTitle) {
        pageTitle.textContent = titles[pageId] || 'Panel de Administración';
    }
}

async function handleQuickAction(action) {
    switch(action) {
        case 'nuevo-producto':
            await openModal('nuevoProductoModal');
            break;
        case 'gestionar-pedidos':
            document.querySelector('[data-page="pedidos"]').click();
            break;
        case 'control-inventario':
            document.querySelector('[data-page="inventario"]').click();
            break;
        case 'ver-reportes':
            document.querySelector('[data-page="reportes"]').click();
            break;
        case 'gestionar-clientes':
            document.querySelector('[data-page="clientes"]').click();
            break;
    }
}

// Modals
function setupModals() {
    const modals = document.querySelectorAll('.modal');
    const closeButtons = document.querySelectorAll('.modal-close');

    closeButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if (modal) {
                closeModal(modal.id);
            }
        });
    });

    modals.forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal(this.id);
            }
        });
    });

    // Open modals
    const nuevoProductoBtn = document.getElementById('nuevoProductoBtn');
    if (nuevoProductoBtn) {
        nuevoProductoBtn.addEventListener('click', () => openModal('nuevoProductoModal'));
    }

    const subirImagenesBtn = document.getElementById('subirImagenesBtn');
    if (subirImagenesBtn) {
        subirImagenesBtn.addEventListener('click', () => openModal('subirImagenesModal'));
    }
}

async function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Si es el modal de nuevo producto, cargar categorías
        if (modalId === 'nuevoProductoModal') {
            await loadCategorias();
        }
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
}

// Forms
function setupForms() {
    const productoForm = document.getElementById('productoForm');
    if (productoForm) {
        productoForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveProducto();
        });
    }

    const uploadImagesForm = document.getElementById('uploadImagesForm');
    if (uploadImagesForm) {
        uploadImagesForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            await uploadImages();
        });
    }
}

// Dashboard
async function loadDashboard() {
    await updateStats();
    loadActivity();
    await loadTopProducts();
    initCharts();
}

async function updateStats() {
    try {
        const response = await fetch(API_BASE + '?action=stats');
        const result = await response.json();
        
        if (result.success && result.data) {
            const data = result.data;
            const totalProductos = data.total_productos || 0;
            const productosActivos = data.productos_activos || 0;
            const totalPedidos = data.total_pedidos || 0;
            const pedidosActivos = data.pedidos_activos || 0;
            const totalClientes = data.clientes_registrados || 0;
            const totalMensajes = data.total_mensajes || 0;
            const mensajesNuevos = data.mensajes_nuevos || 0;
            const totalCotizaciones = data.total_cotizaciones || 0;
            const cotizacionesPendientes = data.cotizaciones_pendientes || 0;
            const ventasMes = data.ventas_mes || 0;

            // Update DOM
            updateElement('total-productos', totalProductos);
            updateElement('pedidos-activos', pedidosActivos);
            updateElement('clientes-registrados', totalClientes);
            updateElement('ventas-mes', formatCurrency(ventasMes));
            
            updateElement('total-productos-mini', totalProductos);
            updateElement('productos-activos-mini', productosActivos);
            updateElement('productos-agotados-mini', data.productos_agotados || 0);
            updateElement('productos-bajo-stock-mini', data.productos_bajo_stock || 0);
            
            updateElement('total-pedidos', totalPedidos);
            updateElement('pedidos-nuevos', data.pedidos_nuevos || 0);
            updateElement('pedidos-proceso', data.pedidos_proceso || 0);
            updateElement('pedidos-pendientes', data.pedidos_pendientes || 0);
            
            updateElement('total-mensajes', totalMensajes);
            updateElement('mensajes-nuevos', mensajesNuevos);
            updateElement('mensajes-pendientes', data.mensajes_pendientes || 0);
            updateElement('mensajes-respondidos', data.mensajes_respondidos || 0);
            
            updateElement('total-cotizaciones', totalCotizaciones);
            updateElement('cotizaciones-badge', cotizacionesPendientes);
            updateElement('productos-badge', totalProductos);
            updateElement('pedidos-badge', pedidosActivos);
            updateElement('mensajes-badge', mensajesNuevos);
        }
    } catch (error) {
        console.error('Error al cargar estadísticas:', error);
    }
}

function updateElement(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = value;
    }
}

function loadActivity() {
    const activityList = document.getElementById('activityList');
    if (!activityList) return;

    const activities = [
        { text: 'Nuevo producto publicado:', product: 'Bikini Soporte Máximo Azul', time: 'Hace 2 horas' },
        { text: 'Nuevo pedido recibido', order: '#ORD-2024-1234', time: 'Hace 4 horas' },
        { text: 'Stock actualizado:', product: 'Traje de Baño Entero Negro', time: 'Hace 1 día' },
        { text: 'Nuevo cliente registrado:', client: 'María González', time: 'Hace 2 días' }
    ];

    activityList.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <strong>${activity.text}</strong>
            ${activity.product ? `<span>${activity.product}</span>` : ''}
            ${activity.order ? `<span>${activity.order}</span>` : ''}
            ${activity.client ? `<span>${activity.client}</span>` : ''}
            <span style="display: block; margin-top: 5px; color: var(--text-light);">${activity.time}</span>
        </div>
    `).join('');
}

async function loadTopProducts() {
    const topProducts = document.getElementById('topProducts');
    if (!topProducts) return;

    // Cargar productos si no están cargados
    if (productos.length === 0) {
        await loadProductos();
    }

    const products = productos.slice(0, 5).map((p, index) => ({
        ...p,
        sales: Math.floor(Math.random() * 50) + 10
    })).sort((a, b) => b.sales - a.sales).slice(0, 3);

    topProducts.innerHTML = products.map((product, index) => `
        <div style="display: flex; align-items: center; padding: 15px; background: var(--bg-color); border-radius: 8px; margin-bottom: 10px;">
            <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--primary-color); color: white; display: flex; align-items: center; justify-content: center; font-weight: 600; margin-right: 15px;">
                ${index + 1}
            </div>
            <div style="flex: 1;">
                <strong>${product.nombre || 'Producto'}</strong>
                <p style="font-size: 12px; color: var(--text-light); margin-top: 5px;">
                    ${product.categoria || 'Categoría'} • ${product.stock || 0} en stock
                </p>
            </div>
            <div style="text-align: right;">
                <strong>${product.sales}</strong>
                <p style="font-size: 12px; color: var(--text-light);">ventas</p>
            </div>
        </div>
    `).join('');
}

function initCharts() {
    const canvas = document.getElementById('salesChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = canvas.offsetWidth;
    canvas.height = 200;

    // Simple line chart
    const data = [120, 190, 300, 500, 200, 300, 450];
    const max = Math.max(...data);
    const width = canvas.width;
    const height = canvas.height;
    const stepX = width / (data.length - 1);
    const stepY = height / max;

    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;
    ctx.beginPath();

    data.forEach((value, index) => {
        const x = index * stepX;
        const y = height - (value * stepY);
        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });

    ctx.stroke();
}

// Categorías
async function loadCategorias() {
    try {
        const response = await fetch(API_BASE + '?action=categorias');
        
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            console.error('Error en loadCategorias - La API no devuelve JSON');
            return;
        }
        
        const result = await response.json();
        if (result.success && result.data) {
            categorias = result.data;
            
            // Cargar categorías en el select del modal
            const categoriaSelect = document.getElementById('modalCategoria');
            if (categoriaSelect) {
                // Limpiar opciones existentes (excepto la primera)
                categoriaSelect.innerHTML = '<option value="">Seleccionar...</option>';
                
                // Agregar categorías
                categorias.forEach(categoria => {
                    const option = document.createElement('option');
                    option.value = categoria.id;
                    option.textContent = categoria.nombre;
                    categoriaSelect.appendChild(option);
                });
            }
            
            // También cargar en el filtro de categorías si existe
            const filterCategoria = document.getElementById('filterCategoria');
            if (filterCategoria) {
                filterCategoria.innerHTML = '<option value="">Todas las Categorías</option>';
                categorias.forEach(categoria => {
                    const option = document.createElement('option');
                    option.value = categoria.id;
                    option.textContent = categoria.nombre;
                    filterCategoria.appendChild(option);
                });
            }
        }
    } catch (error) {
        console.error('Error al cargar categorías:', error);
        categorias = [];
    }
}

// Productos
async function loadProductos() {
    const tbody = document.getElementById('productosTableBody');
    if (!tbody) return;

    try {
        // Cargar desde la API
        const response = await fetch(API_BASE + '?action=productos');
        const result = await response.json();
        
        if (result.success && result.data) {
            productos = result.data;
        } else {
            productos = [];
        }
    } catch (error) {
        console.error('Error al cargar productos:', error);
        productos = [];
    }

    if (productos.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" style="text-align: center; padding: 40px; color: var(--text-light);">No hay productos. <button class="btn btn-primary" onclick="(async () => { await openModal(\'nuevoProductoModal\'); })()">Agregar primer producto</button></td></tr>';
        return;
    }

    tbody.innerHTML = productos.map((producto, index) => `
        <tr>
            <td><input type="checkbox" data-id="${index}"></td>
            <td>
                <div style="width: 50px; height: 50px; background: var(--bg-color); border-radius: 6px; display: flex; align-items: center; justify-content: center; color: var(--text-light);">
                    <i class="fas fa-image"></i>
                </div>
            </td>
            <td>
                <strong>${producto.nombre || 'Sin nombre'}</strong>
                ${producto.descripcion ? `<br><small style="color: var(--text-light);">${producto.descripcion.substring(0, 50)}...</small>` : ''}
            </td>
            <td>${producto.sku || 'N/A'}</td>
            <td>${producto.categoria || 'Sin categoría'}</td>
            <td>${formatCurrency(producto.precio || 0)}</td>
            <td>${producto.stock || 0}</td>
            <td>
                <span class="badge" style="background: ${getEstadoColor(producto.estado)}; color: white; padding: 4px 12px; border-radius: 12px; font-size: 11px;">
                    ${producto.estado || 'activo'}
                </span>
            </td>
            <td>
                <button class="btn btn-secondary" style="padding: 5px 10px; font-size: 12px;" onclick="editProducto(${index})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-secondary" style="padding: 5px 10px; font-size: 12px; margin-left: 5px;" onclick="deleteProducto(${index})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

async function saveProducto() {
    const form = document.getElementById('productoForm');
    
    if (!form) {
        showNotification('Error: No se encontró el formulario', 'error');
        console.error('Formulario productoForm no encontrado');
        return;
    }
    
    // Prevenir envío normal del formulario
    event.preventDefault();
    
    // Obtener valores usando FormData (más confiable)
    const formData = new FormData(form);
    
    // Obtener valores del formulario - buscar por name o por id
    const nombreInput = form.querySelector('[name="nombre"]') || form.querySelector('#nombre');
    const skuInput = form.querySelector('[name="sku"]') || form.querySelector('#sku');
    const categoriaSelect = form.querySelector('[name="categoria_id"]') || form.querySelector('#categoria_id') || form.querySelector('#modalCategoria');
    const precioInput = form.querySelector('[name="precio"]') || form.querySelector('#precio');
    const precioAnteriorInput = form.querySelector('[name="precio_anterior"]') || form.querySelector('#precio_anterior');
    const stockInput = form.querySelector('[name="stock"]') || form.querySelector('#stock');
    const pesoInput = form.querySelector('[name="peso"]') || form.querySelector('#peso');
    const descripcionTextarea = form.querySelector('[name="descripcion_corta"]') || form.querySelector('#descripcion_corta');
    const dimensionesInput = form.querySelector('[name="dimensiones"]') || form.querySelector('#dimensiones');
    const destacadoCheckbox = form.querySelector('[name="producto_destacado"]') || form.querySelector('#producto_destacado');
    
    // Obtener valores - usar FormData primero, luego fallback a value directo
    const nombre = formData.get('nombre') || (nombreInput ? nombreInput.value.trim() : '');
    const sku = formData.get('sku') || (skuInput ? skuInput.value.trim() : '');
    const categoria_id = formData.get('categoria_id') || (categoriaSelect ? categoriaSelect.value : '');
    const precio = formData.get('precio') || (precioInput ? precioInput.value : '');
    const precio_anterior = formData.get('precio_anterior') || (precioAnteriorInput ? precioAnteriorInput.value : '');
    const stock = formData.get('stock') || (stockInput ? stockInput.value : '0');
    const peso = formData.get('peso') || (pesoInput ? pesoInput.value : '');
    const descripcion_corta = formData.get('descripcion_corta') || (descripcionTextarea ? descripcionTextarea.value.trim() : '');
    const dimensiones = formData.get('dimensiones') || (dimensionesInput ? dimensionesInput.value.trim() : '');
    const producto_destacado = destacadoCheckbox ? destacadoCheckbox.checked : false;
    
    // Validar campos requeridos
    if (!nombre || nombre === '') {
        showNotification('Por favor, completa el nombre del producto', 'error');
        if (nombreInput) nombreInput.focus();
        return;
    }
    
    if (!precio || precio === '' || parseFloat(precio) <= 0) {
        showNotification('Por favor, completa el precio del producto', 'error');
        if (precioInput) precioInput.focus();
        return;
    }
    
    const producto = {
        nombre: nombre,
        sku: sku || null,
        categoria_id: categoria_id ? parseInt(categoria_id) : null,
        precio: parseFloat(precio),
        precio_anterior: precio_anterior ? parseFloat(precio_anterior) : null,
        stock: stock ? parseInt(stock) : 0,
        peso: peso ? parseFloat(peso) : null,
        descripcion_corta: descripcion_corta || null,
        dimensiones: dimensiones || null,
        estado: 'activo',
        producto_destacado: producto_destacado
    };
    
    console.log('Datos del producto a enviar:', producto);

    // Validar campos requeridos
    if (!producto.nombre || producto.nombre === '') {
        showNotification('Por favor, completa el nombre del producto', 'error');
        if (nombreInput) nombreInput.focus();
        return;
    }
    
    if (!producto.precio || producto.precio <= 0) {
        showNotification('Por favor, completa el precio del producto', 'error');
        if (precioInput) precioInput.focus();
        return;
    }
    
    console.log('Datos del producto a enviar:', producto);

    try {
        const response = await fetch(API_BASE + '?action=productos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(producto)
        });
        
        // Verificar que la respuesta sea JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            console.error('La API no devuelve JSON. Respuesta:', text.substring(0, 500));
            showNotification('Error: El servidor no está ejecutando PHP. Asegúrate de usar http://localhost (NO abrir el archivo directamente)', 'error');
            throw new Error('La API no está devolviendo JSON. Verifica que estés usando http://localhost y que PHP esté funcionando.');
        }
        
        const result = await response.json();
        
        if (result.success) {
            closeModal('nuevoProductoModal');
            form.reset();
            await loadProductos();
            await updateStats();
            showNotification('Producto guardado exitosamente', 'success');
        } else {
            showNotification('Error: ' + (result.message || 'Error desconocido'), 'error');
        }
    } catch (error) {
        console.error('Error al guardar producto:', error);
        showNotification('Error al guardar producto: ' + error.message, 'error');
    }
}

function editProducto(index) {
    const producto = productos[index];
    // Implementar edición
    showNotification('Función de edición próximamente', 'info');
}

function deleteProducto(index) {
    if (confirm('¿Estás seguro de eliminar este producto?')) {
        productos.splice(index, 1);
        localStorage.setItem('productos', JSON.stringify(productos));
        loadProductos();
        updateStats();
        showNotification('Producto eliminado', 'success');
    }
}

// Pedidos
async function loadPedidos() {
    try {
        const response = await fetch(API_BASE + '?action=pedidos');
        
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            console.error('Error en loadPedidos - La API no devuelve JSON');
            return;
        }
        
        const result = await response.json();
        if (result.success && result.data) {
            pedidos = result.data;
        }
    } catch (error) {
        console.error('Error al cargar pedidos:', error);
        pedidos = [];
    }
    const tbody = document.getElementById('pedidosTableBody');
    if (!tbody) return;

    if (pedidos.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: var(--text-light);">No hay pedidos</td></tr>';
        return;
    }

    tbody.innerHTML = pedidos.map((pedido, index) => `
        <tr>
            <td><strong>${pedido.numero || `#ORD-${index + 1}`}</strong></td>
            <td>${pedido.cliente || 'Cliente'}</td>
            <td>${pedido.productos?.length || 0} productos</td>
            <td>${formatDate(pedido.fecha)}</td>
            <td>${formatCurrency(pedido.total || 0)}</td>
            <td>
                <span class="badge" style="background: ${getEstadoColor(pedido.estado)}; color: white; padding: 4px 12px; border-radius: 12px; font-size: 11px;">
                    ${pedido.estado || 'pendiente'}
                </span>
            </td>
            <td>
                <span class="badge" style="background: ${pedido.pago === 'pagado' ? '#10b981' : '#f59e0b'}; color: white; padding: 4px 12px; border-radius: 12px; font-size: 11px;">
                    ${pedido.pago || 'pendiente'}
                </span>
            </td>
            <td>
                <button class="btn btn-secondary" style="padding: 5px 10px; font-size: 12px;" onclick="viewPedido(${index})">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Mensajes
async function loadMensajes() {
    try {
        const response = await fetch(API_BASE + '?action=mensajes');
        
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            console.error('Error en loadMensajes - La API no devuelve JSON');
            return;
        }
        
        const result = await response.json();
        if (result.success && result.data) {
            mensajes = result.data;
        }
    } catch (error) {
        console.error('Error al cargar mensajes:', error);
        mensajes = [];
    }
    const container = document.getElementById('messagesContainer');
    if (!container) return;

    if (mensajes.length === 0) {
        container.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--text-light);">No hay mensajes</div>';
        return;
    }

    container.innerHTML = mensajes.map((mensaje, index) => `
        <div class="message-item">
            <div class="message-header">
                <div>
                    <span class="message-sender">${mensaje.nombre || 'Usuario'}</span>
                    <span class="message-time">${formatDate(mensaje.fecha)}</span>
                </div>
            </div>
            <div class="message-subject">${mensaje.asunto || 'Sin asunto'}</div>
            <div class="message-content">${mensaje.mensaje || 'Sin contenido'}</div>
            <div class="message-actions">
                <button class="btn btn-primary" style="padding: 5px 15px; font-size: 12px;" onclick="responderMensaje(${index})">
                    <i class="fas fa-reply"></i> Responder
                </button>
                <button class="btn btn-secondary" style="padding: 5px 15px; font-size: 12px;" onclick="marcarLeido(${index})">
                    <i class="fas fa-check"></i> Marcar como leído
                </button>
            </div>
        </div>
    `).join('');
}

// Clientes
async function loadClientes() {
    try {
        const response = await fetch(API_BASE + '?action=clientes');
        const result = await response.json();
        if (result.success && result.data) {
            clientes = result.data;
        }
    } catch (error) {
        console.error('Error al cargar clientes:', error);
        clientes = [];
    }
    const tbody = document.getElementById('clientesTableBody');
    if (!tbody) return;

    if (clientes.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px; color: var(--text-light);">No hay clientes</td></tr>';
        return;
    }

    tbody.innerHTML = clientes.map((cliente, index) => `
        <tr>
            <td>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--accent-color); color: white; display: flex; align-items: center; justify-content: center;">
                        ${cliente.nombre?.charAt(0) || 'C'}
                    </div>
                    <strong>${cliente.nombre || 'Cliente'}</strong>
                </div>
            </td>
            <td>${cliente.email || 'N/A'}</td>
            <td>${cliente.telefono || 'N/A'}</td>
            <td>${cliente.pedidos || 0}</td>
            <td>${formatCurrency(cliente.totalGastado || 0)}</td>
            <td>
                <span class="badge" style="background: #10b981; color: white; padding: 4px 12px; border-radius: 12px; font-size: 11px;">
                    ${cliente.estado || 'activo'}
                </span>
            </td>
            <td>
                <button class="btn btn-secondary" style="padding: 5px 10px; font-size: 12px;">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Cotizaciones
async function loadCotizaciones() {
    try {
        const response = await fetch(API_BASE + '?action=cotizaciones');
        const result = await response.json();
        if (result.success && result.data) {
            cotizaciones = result.data;
        }
    } catch (error) {
        console.error('Error al cargar cotizaciones:', error);
        cotizaciones = [];
    }
    const tbody = document.getElementById('cotizacionesTableBody');
    if (!tbody) return;

    if (cotizaciones.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px; color: var(--text-light);">No hay cotizaciones</td></tr>';
        return;
    }

    tbody.innerHTML = cotizaciones.map((cotizacion, index) => `
        <tr>
            <td><strong>#COT-${String(index + 1).padStart(3, '0')}</strong></td>
            <td>${cotizacion.cliente || 'Cliente'}</td>
            <td>${formatDate(cotizacion.fecha)}</td>
            <td>${cotizacion.productos?.length || 0} productos</td>
            <td>${formatCurrency(cotizacion.total || 0)}</td>
            <td>
                <span class="badge" style="background: ${getEstadoColor(cotizacion.estado)}; color: white; padding: 4px 12px; border-radius: 12px; font-size: 11px;">
                    ${cotizacion.estado || 'pendiente'}
                </span>
            </td>
            <td>${formatDate(cotizacion.vencimiento)}</td>
            <td>
                <button class="btn btn-secondary" style="padding: 5px 10px; font-size: 12px;">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

// Imágenes
async function loadImagenes() {
    try {
        const response = await fetch(API_BASE + '?action=imagenes');
        const result = await response.json();
        if (result.success && result.data) {
            imagenes = result.data;
        }
    } catch (error) {
        console.error('Error al cargar imágenes:', error);
        imagenes = [];
    }
    const grid = document.getElementById('imagesGrid');
    if (!grid) return;

    if (imagenes.length === 0) {
        grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-light);">No hay imágenes. <button class="btn btn-primary" onclick="openModal(\'subirImagenesModal\')">Subir primera imagen</button></div>';
        return;
    }

    grid.innerHTML = imagenes.map((imagen, index) => `
        <div class="image-card">
            <img src="${imagen.url || 'https://via.placeholder.com/200'}" alt="${imagen.alt || 'Imagen'}">
            <div class="image-overlay">
                <p>${imagen.titulo || 'Sin título'}</p>
            </div>
        </div>
    `).join('');
}

function setupImageUpload() {
    const uploadArea = document.querySelector('.image-upload-area');
    const fileInput = document.getElementById('productImages');
    
    if (uploadArea && fileInput) {
        uploadArea.addEventListener('click', () => fileInput.click());
        
        fileInput.addEventListener('change', function(e) {
            const files = Array.from(e.target.files);
            displayUploadedImages(files);
        });
    }

    const uploadImagesInput = document.getElementById('uploadImagesInput');
    if (uploadImagesInput) {
        uploadImagesInput.addEventListener('change', function(e) {
            const files = Array.from(e.target.files);
            displayImagePreview(files);
        });
    }
}

function displayUploadedImages(files) {
    const container = document.getElementById('uploadedImages');
    if (!container) return;

    container.innerHTML = files.map((file, index) => {
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = document.createElement('div');
            img.className = 'uploaded-image';
            img.innerHTML = `
                <img src="${e.target.result}" alt="Preview">
                <button class="remove-image" onclick="removeImage(${index})">
                    <i class="fas fa-times"></i>
                </button>
            `;
            container.appendChild(img);
        };
        reader.readAsDataURL(file);
        return '';
    }).join('');
}

function displayImagePreview(files) {
    const preview = document.getElementById('imagePreview');
    if (!preview) return;

    preview.innerHTML = files.map((file, index) => {
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = document.createElement('img');
            img.src = e.target.result;
            img.style.width = '100px';
            img.style.height = '100px';
            img.style.objectFit = 'cover';
            img.style.borderRadius = '8px';
            img.style.margin = '5px';
            preview.appendChild(img);
        };
        reader.readAsDataURL(file);
        return '';
    }).join('');
}

async function uploadImages() {
    const form = document.getElementById('uploadImagesForm');
    const fileInput = document.getElementById('uploadImagesInput');
    const locationSelect = document.getElementById('imageLocation');
    const tituloInput = form.querySelector('input[type="text"]');
    const descripcionTextarea = form.querySelector('textarea');

    if (!fileInput || !fileInput.files.length) {
        showNotification('Por favor selecciona al menos una imagen', 'warning');
        return;
    }

    const location = locationSelect ? locationSelect.value : 'galeria';
    const titulo = tituloInput ? tituloInput.value : '';
    const descripcion = descripcionTextarea ? descripcionTextarea.value : '';

    // Subir cada imagen
    const uploadPromises = Array.from(fileInput.files).map(async (file) => {
        const formData = new FormData();
        formData.append('imagen', file);
        formData.append('tipo', location);
        formData.append('titulo', titulo || file.name);
        formData.append('descripcion', descripcion);

        try {
            const response = await fetch(API_BASE + '?action=imagenes', {
                method: 'POST',
                body: formData
            });

            // Verificar que la respuesta sea JSON
            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                const text = await response.text();
                console.error('Error: La API no devuelve JSON:', text.substring(0, 200));
                throw new Error('Error al subir imagen: El servidor no respondió correctamente');
            }

            const result = await response.json();
            
            if (result.success) {
                return result.data;
            } else {
                throw new Error(result.message || 'Error al subir imagen');
            }
        } catch (error) {
            console.error('Error al subir imagen:', error);
            showNotification('Error al subir ' + file.name + ': ' + error.message, 'error');
            return null;
        }
    });

    // Esperar a que todas las imágenes se suban
    showNotification('Subiendo imágenes...', 'info');
    const results = await Promise.all(uploadPromises);
    const successful = results.filter(r => r !== null);

    if (successful.length > 0) {
        showNotification(`${successful.length} imagen(es) subida(s) exitosamente`, 'success');
        closeModal('subirImagenesModal');
        form.reset();
        await loadImagenes();
    } else {
        showNotification('No se pudo subir ninguna imagen', 'error');
    }
}

// Tabs
function setupTabs() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Update active tab button
            tabButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Show corresponding tab content
            tabContents.forEach(content => {
                if (content.id === tabId) {
                    content.classList.add('active');
                } else {
                    content.classList.remove('active');
                }
            });
        });
    });
}

// Utility Functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('es-CL', {
        style: 'currency',
        currency: 'CLP',
        minimumFractionDigits: 0
    }).format(amount);
}

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('es-CL');
}

function getEstadoColor(estado) {
    const colors = {
        'activo': '#10b981',
        'inactivo': '#6b7280',
        'agotado': '#ef4444',
        'pendiente': '#f59e0b',
        'en-proceso': '#3b82f6',
        'completado': '#10b981',
        'cancelado': '#ef4444'
    };
    return colors[estado] || '#6b7280';
}

function showNotification(message, type = 'info') {
    // Crear notificación visual
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
        color: white;
        border-radius: 6px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
    
    // También mostrar en consola
    console.log(`[${type.toUpperCase()}] ${message}`);
}

// Sample data initialization
function initializeSampleData() {
    if (productos.length === 0) {
        productos = [
            {
                nombre: 'Bikini Soporte Máximo Azul',
                sku: 'HAI-BIK-001',
                categoria: 'Bikini',
                precio: 29990,
                stock: 15,
                estado: 'activo',
                fechaCreacion: new Date().toISOString()
            },
            {
                nombre: 'Traje de Baño Entero Negro',
                sku: 'HAI-TBJ-002',
                categoria: 'Traje de Baño',
                precio: 34990,
                stock: 8,
                estado: 'activo',
                fechaCreacion: new Date().toISOString()
            }
        ];
        localStorage.setItem('productos', JSON.stringify(productos));
    }
}

// Initialize sample data on first load
initializeSampleData();

